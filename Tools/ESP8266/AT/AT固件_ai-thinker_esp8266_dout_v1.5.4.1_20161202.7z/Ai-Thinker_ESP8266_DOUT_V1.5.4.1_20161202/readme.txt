更新记录：
    内置 AiCloud 2.0 v0.0.3 版本

如何下载：
    1. 该固件已合并 boot_v1.6.bin, user1.bin, esp_init_data_default.bin, blank.bin；
    2. 请使用ESP_DOWNLOAD_TOOL_V2.4 + 以上版本工具下载，下载地址为0x00000；
    3. 如果不知道如何配置Flash选项，请勾选"DoNotChgBin"，这样下载时会按照默认设置下载；
    4. 下载配置可参考 http://wiki.ai-thinker.com/esp_download。
    
    更多信息请访问  http://www.ai-thinker.com/ 或 http://wiki.ai-thinker.com/
    有任何疑问请发送邮件至 support@aithinker.com
    
    安信可科技
    2017-01-10
===================================================================================
Change List：
    AiCloud 2.0 v0.0.3 inside

How to download:

    1. This firmware have already combined boot_v1.6.bin, user1.bin, esp_init_data_default.bin, blank.bin；
    2. Please select the firmware in ESP_DOWNLOAD_TOOL_V2.4 +, The address should write 0x00000;
    3. If you don't know how to config your download panel, please checked the "DoNotChgBin". That will be download the bin as default setting;
    4. Please refer to http://wiki.ai-thinker.com/doku.php/utils/esp_bin_download if you don't know how to download.
    
    More infomation please visit http://www.ai-thinker.com/ or http://wiki.ai-thinker.com/
    If you have any question, please send your mail to support@aithinker.com 
    
    Ai-Thinker
    2017-01-10